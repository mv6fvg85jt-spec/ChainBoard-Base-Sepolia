# ChainBoard — Base Sepolia on-chain guestbook

A compact portfolio dApp: users connect an EVM wallet, publish a short message through a Solidity contract, and read messages stored on Base Sepolia.

## What this demonstrates

- Solidity contract design and input validation
- Contract deployment to an EVM testnet
- Wallet connection and network switching
- On-chain writes, reads, and transaction confirmation
- A small frontend using ethers.js

## 1. Requirements

- Node.js 18 or newer
- MetaMask or another EIP-1193 compatible wallet
- Base Sepolia test ETH (no real funds required)

## 2. Install and compile

From this project folder:

```bash
npm install
npm run compile
```

## 3. Prepare a test wallet

Create a fresh wallet used only for testnet experiments. Never use a wallet containing real funds.

Copy `.env.example` to `.env`. Add the private key of that test-only wallet to `DEPLOYER_PRIVATE_KEY`. Keep `.env private and never upload it to GitHub.

You can leave `BASE_SEPOLIA_RPC_URL` as `https://sepolia.base.org`, or use a reputable Base Sepolia RPC provider.

Get Base Sepolia test ETH from a faucet such as:
https://www.alchemy.com/faucets/base-sepolia

Testnet funds have no intended real-world value.

## 4. Deploy

```bash
npm run deploy:base-sepolia
```

The script prints the deployed contract address and its BaseScan page:
https://sepolia.basescan.org/

Copy the address.

## 5. Configure the frontend

Open `frontend/app.js` and replace:

```js
const CONTRACT_ADDRESS = "PASTE_DEPLOYED_CONTRACT_ADDRESS_HERE";
```

with your deployed address.

## 6. Run the frontend

For a simple local server, from the project root:

```bash
npx serve frontend
```

Open the local URL printed by the server. Connect MetaMask, switch to Base Sepolia when prompted, and publish a test message.

To share the frontend publicly, deploy the `frontend` folder to a static host such as Netlify, Vercel, or GitHub Pages. Do not upload `.env`, private keys, or wallet recovery phrases.

## 7. Verify

After posting, copy the transaction hash shown by the app and open:

`https://sepolia.basescan.org/tx/YOUR_TRANSACTION_HASH`

The transaction should show as successful on Base Sepolia. The message is public and readable by anyone.

## Important before presenting

This repository is source code, not proof of deployment by itself. Only claim it is deployed after you have deployed the contract, configured the frontend, and confirmed a successful transaction on BaseScan. Add your actual contract address, transaction hash, and live demo URL to your portfolio notes.

## Project structure

- `contracts/ChainBoard.sol` — smart contract
- `scripts/deploy.js` — deployment script
- `hardhat.config.js` — Base Sepolia network configuration
- `frontend/` — browser dApp
