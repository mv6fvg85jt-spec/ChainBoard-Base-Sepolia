// After deploying the contract, paste its address below.
const CONTRACT_ADDRESS = "PASTE_DEPLOYED_CONTRACT_ADDRESS_HERE";
const CHAIN_ID_HEX = "0x14a34"; // 84532 = Base Sepolia
const BASE_SEPOLIA = {
  chainId: CHAIN_ID_HEX,
  chainName: "Base Sepolia",
  nativeCurrency: { name: "ETH", symbol: "ETH", decimals: 18 },
  rpcUrls: ["https://sepolia.base.org"],
  blockExplorerUrls: ["https://sepolia.basescan.org/"]
};
const ABI = [
  "function postMessage(string content)",
  "function getMessageCount() view returns (uint256)",
  "function getMessage(uint256 id) view returns (address author, uint64 timestamp, string content)",
  "event MessagePosted(uint256 indexed messageId, address indexed author, uint64 timestamp, string content)"
];

let provider, signer, contract, account;
const $ = (id) => document.getElementById(id);
const configured = /^0x[a-fA-F0-9]{40}$/.test(CONTRACT_ADDRESS);

function setStatus(message, error = false) {
  $("status").textContent = message;
  $("status").style.color = error ? "#ff9b9b" : "#929bad";
}
function shortAddress(address) {
  return address.slice(0, 6) + "…" + address.slice(-4);
}
async function ensureNetwork() {
  try {
    await window.ethereum.request({ method: "wallet_switchEthereumChain", params: [{ chainId: CHAIN_ID_HEX }] });
  } catch (error) {
    if (error.code !== 4902) throw error;
    await window.ethereum.request({ method: "wallet_addEthereumChain", params: [BASE_SEPOLIA] });
  }
}
async function connectWallet() {
  if (!window.ethereum) {
    setStatus("No browser wallet found. Open this site in MetaMask's browser or install a compatible wallet.", true);
    return;
  }
  if (!configured) {
    setStatus("The contract has not been deployed/configured yet. Follow the deployment steps in README.", true);
    return;
  }
  try {
    await ensureNetwork();
    provider = new ethers.BrowserProvider(window.ethereum);
    const accounts = await provider.send("eth_requestAccounts", []);
    account = accounts[0];
    signer = await provider.getSigner();
    contract = new ethers.Contract(CONTRACT_ADDRESS, ABI, signer);
    $("connectBtn").textContent = shortAddress(account);
    $("walletLabel").textContent = shortAddress(account);
    $("postBtn").disabled = false;
    $("postBtn").textContent = "Publish on-chain";
    setStatus("Wallet connected. You're ready to post on Base Sepolia.");
    await loadMessages();
  } catch (error) {
    setStatus(error.shortMessage || error.message || "Wallet connection failed.", true);
  }
}
async function loadMessages() {
  if (!configured) {
    $("messageCount").textContent = "—";
    $("messages").innerHTML = '<div class="empty"><span>✳</span><p>Deploy the contract and add its address in app.js to load on-chain messages.</p></div>';
    return;
  }
  try {
    const readProvider = provider || new ethers.JsonRpcProvider("https://sepolia.base.org");
    const readContract = new ethers.Contract(CONTRACT_ADDRESS, ABI, readProvider);
    const count = Number(await readContract.getMessageCount());
    $("messageCount").textContent = count;
    const items = [];
    for (let i = count - 1; i >= Math.max(0, count - 30); i--) {
      const [author, timestamp, content] = await readContract.getMessage(i);
      const date = new Date(Number(timestamp) * 1000).toLocaleString();
      items.push(`<article class="message"><p>${escapeHtml(content)}</p><div class="message-meta"><span>${shortAddress(author)} · ${date}</span><a href="https://sepolia.basescan.org/address/${CONTRACT_ADDRESS}" target="_blank" rel="noreferrer">Contract ↗</a></div></article>`);
    }
    $("messages").innerHTML = items.length ? items.join("") : '<div class="empty"><span>✳</span><p>No messages yet. Be the first to leave one.</p></div>';
  } catch (error) {
    setStatus("Could not read contract. Check the deployed address and network.", true);
  }
}
function escapeHtml(value) {
  return value.replace(/[&<>"']/g, (char) => ({ "&":"&amp;", "<":"&lt;", ">":"&gt;", '"':"&quot;", "'":"&#39;" }[char]));
}
async function postMessage() {
  const content = $("messageInput").value.trim();
  if (!content) return setStatus("Write a message first.", true);
  if (!contract) return setStatus("Connect your wallet first.", true);
  try {
    $("postBtn").disabled = true;
    $("postBtn").textContent = "Confirm in wallet…";
    setStatus("Waiting for wallet confirmation…");
    const tx = await contract.postMessage(content);
    setStatus(`Transaction submitted: ${tx.hash}`);
    $("postBtn").textContent = "Waiting for confirmation…";
    await tx.wait();
    $("messageInput").value = "";
    $("charCount").textContent = "0 / 280";
    setStatus("Message confirmed on Base Sepolia. Nice work!");
    await loadMessages();
  } catch (error) {
    setStatus(error.shortMessage || error.reason || error.message || "Transaction failed.", true);
  } finally {
    $("postBtn").disabled = !contract;
    $("postBtn").textContent = "Publish on-chain";
  }
}
$("connectBtn").addEventListener("click", connectWallet);
$("postBtn").addEventListener("click", postMessage);
$("refreshBtn").addEventListener("click", loadMessages);
$("messageInput").addEventListener("input", () => $("charCount").textContent = `${$("messageInput").value.length} / 280`);
if (window.ethereum) window.ethereum.on?.("accountsChanged", () => location.reload());
loadMessages();
