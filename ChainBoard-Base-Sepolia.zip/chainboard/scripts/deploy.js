const hre = require("hardhat");

async function main() {
  const [deployer] = await hre.ethers.getSigners();
  console.log("Deploying ChainBoard with:", deployer.address);

  const ChainBoard = await hre.ethers.getContractFactory("ChainBoard");
  const board = await ChainBoard.deploy();
  await board.waitForDeployment();

  const address = await board.getAddress();
  console.log("ChainBoard deployed to:", address);
  console.log(`BaseScan: https://sepolia.basescan.org/address/${address}`);
  console.log("\nNext: paste this address into frontend/app.js (CONTRACT_ADDRESS).");
}

main().catch((error) => {
  console.error(error);
  process.exitCode = 1;
});
